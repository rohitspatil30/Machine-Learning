# modules can be imported which are created by the users also by just making
'''
PyCache is a directory created by Python to store compiled bytecode files (.pyc) that are generated when you run a Python program. These bytecode files help improve the execution speed of Python programs by skipping the compilation step if the source code remains unchanged. The PyCache directory is created automatically when you run a Python script, and it is typically located in the same directory as the corresponding Python file.
'''

import Import_me

print(Import_me.name("Rohit"))

print(Import_me.multiples())

print("this is true that "+Import_me.a)