# there are no array in python language as there is in other languages but there is still list which hold every other property of an array:
# and is even considered better than the the array for following reasons:

# 1) array size is fixed but list does not thave a fixed size alao it is more like a vector with increasing size:

# 2)we can access the elements index wise but we can slice the list which is not possioble in any array: 

# 3)list can hold multiple values and data types which is not in case of array which can hold only one type of data