print("hello world")

print("hello rohit")
#note that by default the next print statement is printed in next line to avoid this.

print("""to avoid the next line escape use (end=\"\") which means end the line with something which is by default \\n also triple quotation allows us to write multiline print statements""", end="ok bye \n")

print("this line wont be printed on new line thanks to (end=\"\")")

# single line comment
 
# """ this a multi line comment 
# please turn green 

# """

print("but to delberately add a new line you can use \\n like \n how this line printed on new line: ")

