# lets now learn the different ways to import a package.
# we import package in many ways.

'''
our folder structure:
modules_and_packages->mainFolder
 |
  ->main.py   --> the python file(module) where we are going to import modules
 | 
  ->package_one -->folder or "package"
    |
    ->module_one.py -->module inside a package
    |
    ->Inside_package_one  -->package inside a package
        |
        ->inside_module_one.py --> module inside nested package
'''


# to import the package
# import package_one #this will import the folder directly. this is the way we import files not folders

import package_one.module_one #right method

import package_one.Inside_package_one.inside_module_one # you imported the inside package/ but importing like this is lengthy process


print("hello this is from main.py")
print(package_one.module_one) #this the way you import 
print(package_one.Inside_package_one.inside_module_one) #sooooo lentghy

from package_one.Inside_package_one import inside_module_one
from package_one.Inside_package_one import inside_module_one as imo # est way to import as we imported the python file and can be accessed directly using file name directly

print(inside_module_one) #better way

print(imo) #best way to access


# print(package_one.module_one) error as we cannot access the file thru folder imports.

