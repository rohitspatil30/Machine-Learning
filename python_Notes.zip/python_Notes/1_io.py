# output

print("hey.",end="")

# input +  strorage(variable)

name = input('what is your name ')
print("hello",name)


