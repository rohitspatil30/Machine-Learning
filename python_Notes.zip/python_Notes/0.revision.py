# str1="Hello world !"
# print(str1 + "sunit")
# print(str1*3)
# print(str1[0])
# print(str1[2:5]) # start with 3 and end with 5
# print(str1[2:]) # start with 3 and char till end

# # In list items are saperated by cooma and enclose in square []
# # to acess end element we use -1 , -2 ., ......
# # acess element from start 0 , 1 , 3 ,.....
# list = [1, 2 ,3 ,4 ,5 ]
# print(list[0:])
# print(list[1:])
# print(list[:])
# print(list[1:3])
# print(list[-1])# print last element
# print(list*6)
# print(list+list)
# print(list[:3])

# # In tuples element cannot be change i.e read only
# a = ('qbcd' ,786 , 2.23)
# tinytuple = ( 123 ,4 )
# print(a[0:])
# print(a[1:])
# print(a[:])
# print(a[1:3])
# print(a[-1])# print last element
# print(a*6)
# print(a+tinytuple)

# #dictionaries
# dict = {}
# tinydict['sunit']={"Very tiny"}
# dict['one']={"THIS is one"}
# print(tinydict[input()])
# print(dict['one'])

# #Even or not
# a=int(input(" Enter number : "))
# if a%2 == 0 :
#     print(" Its a even number ")
# else :
#     print(" Its a OOD number")

# a=int(input(" Enter number : "))
# if a == 0 :
#     print(" Its Zero ")
# elif a>0:
#     print(" Its Positive ")
# else :
#     print(" Its Neagative")

# #to add natrual numbers upto n 
# n=int(input(" Enter number = "))
# sum=0
# i=0
# while(i<=n):
#     sum=sum+i
#     i=i+1
# print(" Sum : ",sum)    

# #to Factorial of  n 
# n=int(input(" Enter number = "))
# sum=1
# i=n
# while(i<=n):
#     sum=sum*i
#     i=i-1
# print(" Factorial : ",sum)    

# fruits=("apples","banana","cherry")
# x=input("Enter fruit name :")
# if x in fruits :
#     print("Fruit is present")        
# else :
#     print("Not present in basket")


# #range function
# for x in range(0,7,2):
#     print(x)

# num = 9
# num_sqrt=print(num*0.5) # * :- exponential operator

# import math
# num= -8
# num_sqrt=num**0.5
# print('The square root of{0} is {1:0.3f}+{2:0.3f}j'.format(num,num_sqrt.real,num_sqrt.imag))

# #Quadratic solving
# import math 
# a= 1 
# b=5
# c=6
# d=(b**2)-(4*a*c)
# sol1=(-b-math.sqrt(d))/(2*a)
# sol2=(-b+math.sqrt(d))/(2*a)
# print('The solution are {0} and {1}'.format(sol1, sol2))

# #swaping
# x=5
# y=10
# x,y=y,x
# print("x : ",x)
# print("y : ", y)

# #funtions
# import math
# x = 3.5 
# y=7
# print(abs(x)) #distace from zero
# print(max(x,y))
# print(min(x,y))
# print(pow(4,3))
# print(math.ceil(x))
# print(math.log(4))
# print(math.cmp(x,y))

# =======================================

# sunit's code

# list=[10,20,30,40,50,60]
# print(list[0:])
# print(list[1:])
# print(list[-1:])
# print(list[:-1])
# print(list[1:4])
# print(type(list))
# list[2]=1000
# print(list)
# list[-1]=00
# print(list)

# #iterating the list
# list=[10,20,30,40,50,60]
# for i in list:
#     print(i)
# # oerations in list
# #append
# list=[10,20,30,40,50,60]
# list.append([2333,344])
# print(list)
# #extend
# list.extend([11,22,33])
# print(list)
# #insert
# list.insert([0,1000])
# print(list)
# #remove
# list.remove(1000)
# print(list)
# list.remove([2333,344])
# print(list)
# #adding of list
# x=[1,2,3]
# y=[4,5,6]
# print(x+y)
# #miltiple the element in list
# print(list*3)
# #maximum
# list.max()

# ==============================================

# sanika ingle's  code :

#Write a python program to print your details
# print("DETAILS")
# print("Name : Sanika Ingle")
# print("Address : D9 Runal Florence, Yamunanagar,Nigdi, Pune")
# print("Age : 19")
# print("Contact Number : 8999241237")
# print("Email : sanika.ingle1998@gmail.com \nCollege Name : JSPM  \nRoll No. : RBT21CB054")
# =================================================================================
#Write a program to add two numbers
# a=1.4
# b=5.6
# c=a+b
# print("The sum of two numbers is :",c)
# =================================================================================
# a=int(input("Enter the first number : "))
# b=int(input("Enter the second number : "))
# c=a+b
# print("The sum of two numbers is : ",c)
# =================================================================================
#print('The sum is %.1f'%(float(input('Enter the first number : ')) + float(input('Enter the second number :'))))
# print("Hello bro")
# a=15
# b=12
# print(a," ",b)
# del (a)
# print(b)
# print(a)
# =================================================================================
# my_dict={}
# print(my_dict)
# my_dict={1:"apple",2:"ball"}
# print(my_dict)
# my_dict={"name":"Ram",1:[2,3,4]}
# print(my_dict)
# my_dict=dict([(1,'apple'),(2,'ball')])
# print(my_dict)
# my_dict={'name':'Ram','age':26}
# print(my_dict['name'])
# print(my_dict['age'])
# my_dict['age']=29
# print(my_dict)
# my_dict['Address']='JSPM'
# print(my_dict)
# squares ={1:2,2:4,3:9,4:16,5:25}
# print(squares.pop(4))
# print(squares)
# print(squares.popitem())
# print(squares)
# print(squares.clear())
# =================================================================================
# mark={}.fromkeys(['dict3','dict2','dict4'],0)
# print(mark)
# for items in mark.items():
#     print(items)
#     print(list(sorted(mark.keys())))
# squares={x:x**2 for x in range(30) if x%3==0}
# for i in squares :
#     print(squares[i])
# print(squares)
# print(all(squares))
# print(any(squares))
# print(sorted(squares))
# print(len(squares))
# =================================================================================
# mark={}.fromkeys(['dict3','dict2','dict4'],0)
# print(mark)
# for items in mark.items():
#     print(items)
#     print(list(sorted(mark.keys())))
# squares={x:x**2 for x in range(30) if x%3==0}
# for i in squares :
#     print(squares[i])
# print(squares)
# print(all(squares))
# print(any(squares))
# print(sorted(squares))
# print(len(squares))
# =================================================================================
# i=1
# a=int(input("Enter the number : "))
# fact=1
# while(i<=a):
#     fact=fact*i
#     i+=1
# print("Factorial of number is : ",fact)
# =================================================================================
# def printinfo(name,age):
#     "This prints a passed info into this function"
#     print("Name : ",name)
#     print("Age :",age)
#     return;
# printinfo(age=50,name="Sanika")
# =================================================================================
# list=[1,"Hello",7.4,'a',"Sanika"]
# print(list[-1])
# print(list[2:4])
# print(list[4])
# print(list)
# print(type(list))
# print(list[:-1])
# print(list[:])
# =================================================================================
# even=[2,10,11,12]
# even.insert(2,4)
# print(even)
# even.sort()
# print(even)
# del even[2]
# print(even)
# even.remove(11)
# print(even)
# even.remove(4)
# print(even)
# even.pop(0)
# print(even)
# even.pop()
# print(even)
# even.insert(0,150)
# print(even)
# pow2=[2**x for x in range(15)]
# print(pow2)
# =================================================================================
# a=int(input("Enter the number : "))
# if(a>0):
#     print("number is positive")
# elif(a==0):
#     print("Number is zero")
# else:
#     print("Number is negative")
# =================================================================================
# i=1
# while(i<6):
#     print(i)
#     i+=1
# =================================================================================
# print("Enter your number : ")
# inpnum=input()
# print("You entered ", inpnum+"10")
# =================================================================================
# var=100
# if(var==100):
#     print("Value of expression is 100")
#     print("Good Bye")
# =================================================================================
# a=int(input("Enter the number : "))
# if(a%2==0):
#     print("number is even")
# else:
#     print("Number is odd")
# =================================================================================
# fruits=["apple","banana","cherry"]
# for x in fruits:
#     print(x)
#     if x=="banana":
#         break
# =================================================================================
# import math
# a=1
# b=5
# c=6
# d=(b**2)-(4*a*c)
# sol1=(-b-math.sqrt(d))/(2*a)
# sol2=(-b+math.sqrt(d))/(2*a)
# print("The solution are{0} and {1}".format(sol1,sol2))
# =================================================================================
# x=5
# y=10
# x,y=y,x
# print("x=",x)
# print("y=",y)

#swap using add and subtract
# x=x+y
# y=x-y
# x=x-y

#swap using multiplication and division
# x=x*y
# y=x/y
# x=x/y
# =================================================================================
# add natural numbers upto n
# sum=0
# n=int(input("Enter the number :"))
# i=1
# while(i<=n):
#     sum=sum+i
#     i+=1
# print("Sum of numbers is :",sum)
# =================================================================================
# tuple=()
# print(tuple)
# natural=(1,2,3,4,5,6)
# print(natural)
# ntuple=("mother",[2,3,4],(1,2,3))
# print(ntuple)
# tuple=5,10,15,20,4,5,'a'
# print(tuple)
# tuple=("Hello",)
# print(type(tuple))
# tuple="hello",
# print(type(tuple))
# tuple=('a','b','c','d')
# print(tuple[0])
# print(tuple[-2])
# print(tuple[2:5])
# print(tuple.count('a'))
# print(len(tuple))
# =================================================================================
# odd=[2,4,6,8]
# odd[0]=1
# print(odd[:])
# odd[1:4]=[3,5]
# print(odd[:])
# odd.append(7)
# print(odd)
# odd.extend([9,11,13,15])
# print(odd)
# even=[2,4,6,8]
# naturalnumbers=even+odd
# print(naturalnumbers)
# naturalnumbers.sort()
# print(naturalnumbers)
# n=naturalnumbers*3
# print(n)
# n.sort()
# print(n)
# =================================================================================

# function : 

# def info(a):
#     return a*a
# w=info(4)
# print(w)
# ==================================================================================

#  retrun max of 2: 

# def max(a,b,c):
#     if(a>b and a>c):
#         return a
#     elif(b>a and b>c):
#         return b
#     else:
#         return c

# print(max(23,2,4))

# ==================================================================================

# def multiply(numbers):
#     total = 1
#     for x in numbers:
#         total *=x
#     print("the answer iS: ",total)
# multiply(((1,2,3)))

# ================================================================================

# sanket codes: 

# ==============================================================================


# num = input("Enter the no:")
# if (int(num) % 2) == 0:
#     print("given no is even")
# else:
#     print("given no is odd")
# #
# if (int(num) % 7) == 0:
#     print("The num is divisible by 7")
# else:
#     print("It is not divisible by 7")
# # check if the no is +ve -ve or zero
# num2 = input("enter the no.:")
# if int(num2) > 0:
#     print("it is positive number")
# elif int(num2) == 0:
#     print("it is a zero")
# else:
#     print("The given number is -ve")

# # while loop
# ==============================================================================

# #  write a pro to add no till n ; take value of n from user
# i = 0
# while i < 10:
#     print(i)
#     i += 1

# ==============================================================================

# factorial : 

# i = 1
# ans = 1
# num = int(input("enter a non-zero num for its factorial:"))
# while i <= num:
#     ans = ans * i
#     i += 1
# print("factorial is:", ans)


# ==============================================================================

# math fcunctionS:

# import math

# x = 10
# y = 5
# print(abs(x))
# print(math.ceil(x))
# print(math.exp(x))

# ==============================================================================

# lists: 

# list = ['abc','def', 1, 2, 3, 'sanket', 4.5]
# list2 = [123,'8']
# print("list1 is: ", list)
# print("list2 is: ", list2)
# print(list[2:])
# print(list[:5])


# ==============================================================================
# addition of number till n = input by user

# import math

# n = int(input("enter the no:"))
# i = 1
# sum = 0
# while i <= n:
#     sum += i
#     i += 1

# print(sum)

# # for loop

# fruits = ['apple', 'cherry', 'banana', 'peach', ]
# for x in fruits:
#     if x == 'banana':
#         break
#     print('fruit')

# for x in fruits:
#     if x == 'banana':
#         continue
#     print('fruit')

# for x in range(3,7):
#     print(x)
# no = 9
# num_sqrt = no ** 0.5
# print("The square root of %0.3f is %0.3f"%(no, num_sqrt))

# no = 49
# num_sqrt = math.sqrt(no)
# print("the sqrt od {0} is {1:0.3f}+{2:0.3f}j".format(no,num_sqrt))


# ==============================================================================

# quadratic : 

# import math
# a = 1
# b = 5
# c = 6
# d = (b**2) - (4*a*c)
# sol1 = (-b-math.sqrt(d))/ (2 * a)
# sol2 = (-b+math.sqrt(d))/ (2*a)

# print('the solution are {0} and {1}'.format(sol1,sol2))

# ==============================================================================


# swapping : 

# x = 5
# y = 10

# x, y = y, x
# print(x, y)

# x = x + y
# y = x - y
# x = x-y
# print(x, y)

# x = x*y
# y = x/y
# x = x/y
# print(x, y)


# ==============================================================================
# python dictionaries: 

# mydict = {'name': 'ram', 'age': 26}
# print(mydict['name'])
# print(mydict['age'])
# # changing & adding element in dict
# mydict['age'] = 29
# print(mydict['age'])
# mydict['address'] = 'JSPM RSCOE'
# print(mydict)
# squr = {1: 1, 2: 4, 3: 9, 4: 16, 5: 25}
# print(squr.pop(4))
# print(squr)
# print(squr.popitem())
# squr.clear()
# print(squr)
# del squr
# marks = {}.fromkeys(['math', 'eng', 'sci'], 0)
# print(marks)
# print(list(sorted(marks.keys())))
# squr = {x:x*x for x in range(10)}
# print("square is:", squr)
# squr = {x:x*x for x in range(10) if (x % 2) == 0}
# print("Square of even no:", squr)
# for i in squr:
#     print(squr[i])
# print(all(squr))
# print(any(squr))
# print(sorted(squr))

# ==============================================================================

# fucntions:

# def printme( str ):
#     "this prints a passed string into this function"
#     print(str)
#     return
# string = input("enter the string:")
# printme(string)
# def changeme(mylist):
#     mylist.append([1,2,3,4]);
#     print("value inside the function is : ",mylist)
#     return
# mylist = [10, 20, 30]
# changeme(mylist)
# print("value of outside function is ",mylist)

# ==============================================================================
# list functions : 

# i = 1
# list = []
# print("Table of 2 is:")
# for i in range(1, 11):
#     list.append(i*2)
# print(list)
# list.append('grapes')
# list.append('apple')
# list.append('hello')
# print("Given list is:", list)
# print(list[0])
# print(list[4:])
# print(list[4:10])
# print(list[-1])
# print(list[-3])
# print(list.index('grapes'))

# # correcting mistakes in list
# odd = [2, 4, 6, 8]
# print(odd)
# odd[0] = 1
# print(odd)
# odd[1:4] = [3, 5, 7]
# print(odd)

# # append and extend list:

# odd.append([9, 11, 13])
# print(odd)
# odd.extend([15, 17, 19])
# print(odd)
# even = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
# print(odd+even)
# print(('list is :', even)*3)
# even.insert(5, 22)
# print(even)
# even[2:2] = [5, 7]
# print(even)

# # delete element in list:
# del even[12]# del element item in 12th index
# print(even)
# del even[1:5]
# print(even)
# del even # del whole list now even needs to be declared again
# print(odd)
# odd.remove(15)
# print(odd)
# odd.pop(3)
# print("poped list:", odd)
# print(odd.pop(3))
# print(odd)
# odd.pop()
# print(odd)
# odd.clear()
# print(odd)
# del odd
# del list

# # list comprehension
# pow2 = [2**x for x in range(10)]
# print(pow2)
# # method 2
# pow2 = []
# for x in range(10):
#     pow2.append(2**x)
# print(pow2)
# del pow2
# print("\n")
# # iterating list

# fruit = ['apple', 'banana', 'mango']
# for fruit in ['apple', 'banana', 'mango']:
#     print("I like :", fruit)

# ==============================================================================

# tuples : 

# tuple = ()  # empty tuple
# print(tuple)
# tuple = (1, 2, 3, 4, 5)
# print(tuple)
# # nested tuple
# ntuple = ("hello", "hi", 6, 7)
# print(ntuple)

# # tuple packing / packing of tuple
# tuple = 5, 6, 7, 8
# print(tuple)

# # unpacking of tuple
# a, b, c, d = tuple
# print(tuple)
# print(a, b, c, d)

# # type if tuple
# tuple = ("hello")
# print(type(tuple))
# tuple = ("hello", "hi")
# print(type(tuple))
# tuple = "hello",  # after ',' it will be tuple or a single element will be string
# print(type(tuple))
# print(tuple)
# tuple = ('a', 'b', 'c', 'd', 'e')
# print(tuple[0])
# print(tuple)
# print(tuple[-2])
# print(tuple[-3])
# # tuple[1] = "p"  # elements cant be change function like append remove will not work in tuple
# # del tuple[3] print(tuple) tulple cant be edited whole tuple can be deleted not just 1 element
# print(tuple.count('a'))  # gives nth no. of element
# print(tuple.index('b'))  # gives the arr index
# del tuple

# for name in ('john', 'alex', 'abc'):
#     print("hello", name)
# print(type(name))


# ==============================================================================

# varable name arg

# def printinfo(arg1, *vartuple):
#     "this prints a variable passed argument"
#     print("Output is:")
#     print(arg1)
#     for var in vartuple:
#         print(var)
#     return


# printinfo(10)
# printinfo(70,80,90,100)

# ==============================================================================


# passing the arguments: 

# def printer(str):
#     "This function prints the given string"
#     print(str)
#     return


# print("the function starts")
# string = input("enter your string:")
# printer(string)
# print("the function starts")
# # string = input("enter your string:")
# printer(str='hello')
# # function definition


# def printinfo(name, age):
#     print("Name is:", name)
#     print("his age is:", age)
#     return


# name = input("Enter the name: ")
# age = int(input("enter the age: "))
# printinfo(name, age)
# printinfo(name="unknown", age="")

# ==============================================================================

# syntax of anonymous function
# lambda [arg1 [,arg2,......,argn]]: expression

# def product (arg1, arg2):
#     prod = arg1 * arg2
#     print("inside the function:", prod)
#     return prod


# sum = lambda arg1, arg2: arg1 + arg2


# print("value of total :", sum(20, 50))
# print("value of product+ :", product(20, 50))





# ==============================================================================
# file handling: 

# fo = open("foo.txt","wb")
# print("name of file:",fo.name)
# print("closed")

# ==============================================================================


# file handling continued :

# def printer(str):
#     "This function prints the given string"
#     print(str)
#     return


# print("the function starts")
# string = input("enter your string:")
# printer(string)
# print("the function starts")
# # string = input("enter your string:")
# printer(str='hello')
# # function definition


# def printinfo(name, age):
#     print("Name is:", name)
#     print("his age is:", age)
#     return


# name = input("Enter the name: ")
# age = int(input("enter the age: "))
# printinfo(name, age)
# printinfo(name="unknown", age="")

# # nested function


# def test(a):
#     def add(b):
#         nonlocal a
#         a +=1
#         return a+b
#     return add


# func = test(4)
# print("nested function ans:", func(4))
# ==============================================================================

# palindrome check : 

# def ispalindrome(string):
#     lef_pos = 0
#     right_pos = len(string) -1

#     while right_pos >= lef_pos:
#         if not string[lef_pos] == string[right_pos]:
#             return False
#         lef_pos += 1
#         right_pos -= 1
#     return True


# print(ispalindrome('madam'))

# ==============================================================================

# write a pro to multiply elements inlist

# def multi(arg):
#     total = 1
#     for x in arg:
#         total *=x
#     return total


# list = (9, 7, 4, 5)
# print("list1 is :", multi((7, 8, -9, -5)))
# print("list2 is :", multi(list))

# # print reverse of string


# def strrev(str1):
#     rstr1 = ''
#     index = len(str1)
#     while index > 0:
#         rstr1 += str1[index - 1]
#         index = index - 1
#     return rstr1


# print(strrev('123abcde'))
# string = input("enter your string: ")
# print("reverse of your str is: ", strrev(string))

# # print no of lower and upper case in string


# def str_test(s):
#     d = {"UPPER_CASE":0, "LOWER_CASE": 0}
#     for c in s:
#         if c.isupper():
#             d["UPPER_CASE"] += 1
#         elif c.islower():
#             d["LOWER_CASE"] += 1
#         else:
#             pass
#     print("Original string: ", s)
#     print("NO. of Upper case char: ", d["UPPER_CASE"])
#     print("No. of LOWER_CASE char: ", d["LOWER_CASE"])


# s = input("enter your string")
# str_test(s)



# ==============================================================================

# find max no. between 3 no.

# def maxm(num1, num2, num3):
#     d = max(num1,num2,num3)
#     print("the max no. is:", d)
#     return max


# a = int(input("enter 1st no.:"))
# b = int(input("enter 2nd no.:"))
# c = int(input("enter 3rd no.:"))

# maxm(a, b, c)

# # method2


# def maxof2(x,y):
#     if( x > y):
#         return x
#     return y


# def maxof3(x, y, z):
#     return maxof2(x,maxof2(y, z))


# print("using method 2:")
# print("max no. is:", maxof3(a, b, c))

# ==============================================================================

# class node:
#     #singly link list node
#     def __init__(self,data=None):
#         self.data = data
#         self.next = None

# class singly_link_list:
#     def __init__(self):
#         #creat an emptylist
#         self.head = None
#         self.tail = None
#         self.count = 0

#     def iterate_item(self,data):
#         # iterate the list
#         current_item = self.head
#         while current_item:
#             val = current_item.data
#             current_item = current_item.next
#             yield val
#         def append_item(self,data):
#             # appends items on the list
#             node = Node(data)
#             if self.tail:
#                 self.tail.next = node
#                 self.tail = node
#             else:
#                 self.head = node
#                 self.tail = node
#             self.count += 1
#     items = singly_link_list()
#     items.append
# ==============================================================================


# global variable declaration: 
# total = 0
# a = 100


# def printer(num1,num2):
#     total = num1+num2
#     print("the value in side function is: ", total)
#     a = total

# printer(10,50)
# print("value outside function:", total)
# a = printer(40,50)
# print("a= ",a)


# total = 0 in global # total = >0 because it is local var of printer

# ==============================================================================


# variable name arg : 

# def printinfo(arg1, *vartuple):
#     "this prints a variable passed argument"
#     print("Output is:")
#     print(arg1)
#     for var in vartuple:
#         print(var)
#     return


# printinfo(10)
# printinfo(70,80,90,100)
# ==============================================================================

# def print_func(par):
#     print("Hello: ", par)
#     return
# # import statement
# # import module1[,module2,module3,..........]]
# # import *   #  it will import all libraries

# # the module is sotred in module in sys.

# # PYTHONPATHVARIABLE
# '''set PYTHONPATH = c:\python20\lib;'''
# # namespace and scope
# '''namespace is a directory'''
# '''reload (module-name) reloades the modual as new'''
# '''reading keyboard input
# raw_input
# input

# raw_input for big string'''

# ==============================================================================
# import moduleday4
# moduleday4.print_func("Sanket")
# ==============================================================================







