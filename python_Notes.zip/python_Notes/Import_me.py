def name(n):
    return "Hello "+n


def multiples():
    return ([num for num in range(1,106) if(num%5==0)])


a="rohit is a bad boy"