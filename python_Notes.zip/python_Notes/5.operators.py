# from ast import operator


# operator

# types of operator:


a=4
b=5


# arithmetic  operaition: 

# print(a+b)
# print(a-b)
# print(a*b)
# print(a/b)
# print(a**b)
# print(a//b)
# print(a%b)

# assignment operator:

# = equal to assignment.
a+=5
print(a)
a-=5
print(a)
a*=5
print(a)
# a/=5
print(a)
a//=5
print(a)
a**=5
print(a)
a%=5
print(a)
# bitwise cannot be applied on float
a=5
a<<=5
print(a)
a>>=5 
print(a)
a^=5
print(a)
a=~a
print(a)
a&=5
print(a)
a|=5
print(a)



# comparison operator 

# > < == <= >= != 

# always returns a boolean value used to take decisions: 
# also used to run the if else ladder: 


# a=80
# b=45

# print(a>b)
# print(a!=b)
# print(b>a)
# print(a==b)
# print(a<=b)
# print(a>=b)


# logical operator c++ && || !

# but in python they are words: 
# and or not 

# they are used in the combination with relational operator : 

# a=45
# b=30

# # like relational operator: they also return boolean value used to compare two or more relations

# print(a>b and a<b) # false
# print(a>=b or a==b) # true
# print(not(a>b) and not(a<=b)) # false 
# print((not(a==b and a>b)) or (( a>b) and (not(b!=a)))) #true





# # identity operator 
# a=45
# b=70

# # is : returns true if the variables are equal  else return false
# # is not : returns true if the var is not equal else return false

# print(a is b)
# # print(a==b) # alternate version  

# print(a is not b)
# print(a != b) #alt ver
 

# x= 'rohit'
# y ='rohit'

# print(x == y)
# print(x is y)




# membership operator: returns bool

# a= " rohit patil "

# print(" " in a)
# print("h" in a)

# print("x" not in a )
# print("i" not in a)

# b=45
# print(4 in b)<--------------error 



# bitwise operator: 
#  << >> & | ~ ^

# a=4
# b=5
# this return answer like in arithmetic

# print(a & b) # 4
# print(a|b) # 5
# print(~a) # -5 unsigned
# print(a^b) # 1
# print(a<<b) # 128
# print(a>>1) # 2








