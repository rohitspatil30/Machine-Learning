# if statement:

a=4
b=6
c=41
# normal use: 

# if b<a:
#     print("hello")
# elif c<a  or c>b:
#     print("whatsapp")
# else:
#     print("hi")



# if using bool

# bools=True
# bOOLs=False

# if bOOLs:#because the if is flase carrier
#     print("the statement is true")
# else : 
#     print("the statement is not: ")


#using number:

# num1=34
# num2=-45
# num=0

# if num:
#     print("hi")
# elif num2:
#     print("hello")
# else :
#     print("whatsapp")
# any number except 0 is considered true


# using funcs:

# in and not in operator:

# li=[1,2,3,4]
# print(2 in li)
# print (2 not in li)
# print (21 not in li)

# if 3 in li:
#     print("hi")
# else: 
#     print("wow")
# ===============================================================================


# question: 
# print whether a person can vo or not:

# age=int(input("enter your age: "))
# if age>=18:
#     print("you can vote: ")
# else:
#     print("you cannot vote: ")

# ======================================================

# can be triggered by 

# bools
# numbers
# strings
# relational operator
# more then one relational operator using logical operator
# functions
# list
# tuple
# set
# dictionary

# =============================================================================

# the end line is the if statement will be executed only when the if condition is satisfied else the elif condition will be checked and if all the conditionas are false then the else contion will be executed.

# ==========================================================================

# short hand if:

if a!=b : print("hi")

# =========================================================================

# short hand if else:

print("b") if b>a else print("a")

# ===========================================================================

if b>=1 :
    pass

# when you dont have any work for if else:


